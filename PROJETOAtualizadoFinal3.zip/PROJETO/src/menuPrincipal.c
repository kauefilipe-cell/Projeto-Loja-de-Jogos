// menu da loja de jogos, onde o cliente pode escolher entre pesquisar os jogos ou cadastrar novos jogos no sistema, comprar jogos ou sair do sistema.
#include <stdio.h>
#include <stdlib.h>
#include "biblioteca/arquivoTXT.h"
#include "biblioteca/avaliacoes.h"
#include "biblioteca/relatorio.h"

int main()
{
    int menu;
    // Pesquisa de jogos; cadastro de jogos; compra de jogos;

    do
    {
        printf("\n=====================================\n");
        printf("          MENU DE JOGOS\n");
        printf("=====================================\n");
        printf("(1) - Pesquisar jogos\n");
        printf("(2) - Cadastrar novos jogos no sistema\n");
        printf("(3) - Registrar venda de jogos\n");
        printf("(4) - Gerar relatorio\n");
        printf("(5) - Registrar avaliação\n");
        printf("(6) - Relatório de avaliações\n");
        printf("(0) - Sair!!\n");
        printf("Digite o que vc deseja utilizar: ");
        scanf("%d", &menu);

        switch (menu)
        {
        case 1:
        {

            char nomeJogo[30];

            printf("Digite o nome do jogo que deseja pesquisar: ");
            scanf("%s", nomeJogo);

            // chamar a função para buscar o jogo escolhido, caso o jogo escolhido não exista, exibir uma mensagem de erro
            buscarJogo(nomeJogo);
            break;
        }
        case 2:
        {

            int numeroJogos;

            printf("Digite o número de jogos a cadastrar: ");
            scanf("%d", &numeroJogos);

            // verificar se o arquivo já existe, caso o arquivo já exista, não será criado um novo arquivo, apenas será aberto o arquivo existente
            if (numeroJogos > 0 && fopen("arquivos/jogos.txt", "r") == NULL)
            {
                // criarArquivo();
                criarArquivo(numeroJogos);
            }else if (numeroJogos > 0)
            {
                // chamar a função para editar o arquivo e adicionar um novo jogo ao final do arquivo
                editarArquivo(numeroJogos);
            }

            break;
        }
        case 3:
        {

            char nomeJogo[30];
            int quantidade;

            printf("Digite o nome do jogo que deseja comprar: ");
            scanf("%s", nomeJogo);

            printf("Digite a quantidade de jogos que deseja comprar: ");
            scanf("%d", &quantidade);

            // chamar a função para atualizar as vendas do jogo escolhido, caso o jogo escolhido não exista, exibir uma mensagem de erro
            atualizarVendas(nomeJogo, quantidade);

            // chamar a função para ler o arquivo e exibir os dados lidos do arquivo
            lerArquivo();
            break;
        }
        case 4:

            // chamar a função para gerar um relatório e exibir os dados especificos
            gerarRelatorio();
            break;

        case 5:

            // chamar a função para registrar avaliação de algum jogo
            registrarAvaliacao();
            break;

        case 6:
        
            // chamar a função para exibir as avaliações
            exibirQuantidadeAvaliacoes();
            exibirMediaAvaliacoes();
            exibirJogoMaisBemAvaliado();
            break;

        case 0:

            // sair do sistema
            printf("Saindo do sistema...\n");
            break;
        }
    } while (menu != 0);

    printf("\nVc saiu do sistema\n");

    printf("=====================================\n\n");
}
