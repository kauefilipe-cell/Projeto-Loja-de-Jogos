# 🎮 Sistema de Cadastro de Jogos

## 📖 Descrição
Este projeto é um sistema desenvolvido em linguagem C para gerenciamento de jogos. Ele permite cadastrar jogos, armazenar informações em arquivos, registrar avaliações e gerar relatórios com médias.

O sistema foi desenvolvido com foco em manipulação de arquivos, modularização do código e organização em bibliotecas.

---

## ⚙️ Funcionalidades
- Cadastro de jogos
- Armazenamento de dados em arquivo `.txt`
- Listagem de jogos cadastrados
- Registro de avaliações por jogo
- Cálculo de média das avaliações
- Geração de relatórios

---

## 🧰 Tecnologias utilizadas
- Linguagem C
- Manipulação de arquivos (fopen, fwrite, fread, fclose)
- Estruturas (structs)
- Modularização com múltiplos arquivos `.c`
- GCC (compilador)

---

## 📂 Como utilizar

- make: para compilar os arquivos
- make run: para rodar o .exe criado pelo make

---

## 🔗 Link do git

- https://github.com/kauefilipe-cell/Projeto-Loja-de-Jogos.git

---

## 👥 Autores

- Emanuelle Krempi Mariotto
- Giovanna Taila Risoli
- Kauê Filipe Nascimento de Oliveira