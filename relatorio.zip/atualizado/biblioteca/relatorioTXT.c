//biblioteca de funções para geraçãio de relatórios

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

struct Relatorio{
    char jogo_vendido[30];
    int qtd_dowload;
    float faturamento_bruto;
    float faturamento_liquido;
    float media_jogos_disponiveis;
    float media_jogos_vendidos;
    char jogo_caro[30];
    char jogo_barato[30];
    float preco_caro;
    float preco_barato;
};
struct Jogos{
    char nome[30];
    char genero[10];
    float preco;
    int classificacao;
    int vendas;
    float faturamento;
};
void gerarRelatorio (){
    struct Jogos jogo[255];
    
    // 3. Verificar se o arquivo foi aberto com sucesso
    if (jogo == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return;
    }

    // 4. Ler os dados do arquivo usando fscanf
    int i = 0, totalJogos = 0;
    while (fscanf(jogo, "{\n   %[^;];%[^;];%f;%d;%d;%f\n}\n", jogo[i].nome, jogo[i].genero, &jogo[i].preco, &jogo[i].classificacao, &jogo[i].vendas, &jogo[i].faturamento) == 6){
        totalJogos++;
        i++;
    }

    // Exibir os dados lidos
    for (int j = 0; j < i; j++) {
        printf("Nome: %s\nGênero: %s\nPreço: %.2f\nClassificação: %d\nVendas: %d\nFaturamento: %.2f\n\n", jogo[j].nome, jogo[j].genero, jogo[j].preco, jogo[j].classificacao, jogo[j].vendas, jogo[j].faturamento);
    }

    // 5. Fechar o arquivo (importante!)
    fclose(jogo);
        
    /*struct Relatorio relatorios [300];
    FILE *relatorio;
    relatorio = fopen("jogos.txt", "r");*/
};
    

