#ifndef AVALIACOES_H
#define AVALIACOES_H

void registrarAvaliacao();
void exibirQuantidadeAvaliacoes();
void exibirMediaAvaliacoes();
void exibirJogoMaisBemAvaliado();

#endif