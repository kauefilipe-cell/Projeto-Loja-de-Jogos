#include <stdio.h>
#include "relatorio.h"

// Struct utilizada para armazenar os dados dos jogos
struct Jogos{
    char nome[30];
    char genero[20];
    float preco;
    int classificacao;
    int vendas;
    float faturamento;
};

// Função responsável por gerar o relatório geral da loja
void gerarRelatorio(){

// Vetor que armazenará os jogos lidos do arquivo
    struct Jogos jogo[255];

// Ponteiro para o arquivo
    FILE *arquivo;

// Abre o arquivo no modo leitura
    arquivo = fopen("jogos.txt", "r");

// Verifica se o arquivo foi aberto corretamente 
    if(arquivo == NULL){
        printf("Erro ao abrir o arquivo!\n");
        return;
    }

// Variável que armazenará a quantidade de jogos encontrados
    int totalJogos = 0;

// Lê todos os jogos do arquivo e armazena no vetor
    while(totalJogos < 255 &&
          fscanf(arquivo,
          "{\n   %[^;];%[^;];%f;%d;%d;%f\n}\n",
          jogo[totalJogos].nome,
          jogo[totalJogos].genero,
          &jogo[totalJogos].preco,
          &jogo[totalJogos].classificacao,
          &jogo[totalJogos].vendas,
          &jogo[totalJogos].faturamento) == 6)
    {
        totalJogos++;
    }

// Fecha o arquivo após a leitura
    fclose(arquivo);

// Verifica se existe pelo menos um jogo cadastrado
    if(totalJogos == 0){
        printf("\nNenhum jogo cadastrado!\n");
        return;
    }

// Índices que armazenarão a posição dos jogos especiais
    int indiceMaisVendido = 0;
    int indiceMaisCaro = 0;
    int indiceMaisBarato = 0;

// Variáveis para os cálculos do relatório
    int totalDownloads = 0;

    float faturamentoBruto = 0;
    float faturamentoLiquido = 0;
    float imposto = 0;

    float somaPrecos = 0;
    float somaPrecosVendidos = 0;

    int quantidadeJogosVendidos = 0;

// Percorre todos os jogos cadastrados
    for(int i = 0; i < totalJogos; i++){

//Cálcular dowload
        totalDownloads += jogo[i].vendas;

//Faturamento
        faturamentoBruto +=
            jogo[i].preco * jogo[i].vendas;

// Soma os preços para calcular a média dos jogos disponíveis
        somaPrecos += jogo[i].preco;

// Considera apenas jogos vendidos para calcular a média dos vendidos
        if(jogo[i].vendas > 0){
            somaPrecosVendidos += jogo[i].preco;
            quantidadeJogosVendidos++;
        }

// Verifica qual é o jogo mais vendido
        if(jogo[i].vendas >
           jogo[indiceMaisVendido].vendas){
            indiceMaisVendido = i;
        }

// Verifica qual é o jogo mais caro
        if(jogo[i].preco >
           jogo[indiceMaisCaro].preco){
            indiceMaisCaro = i;
        }

// Verifica qual é o jogo mais barato
        if(jogo[i].preco <
           jogo[indiceMaisBarato].preco){
            indiceMaisBarato = i;
        }
    }

// Calcula o valor dos impostos (20%)
    imposto = faturamentoBruto * 0.20;
    
// Calcula o faturamento líquido
    faturamentoLiquido =
        faturamentoBruto - imposto;

// Calcula a média dos preços dos jogos cadastrados
    float mediaJogos =
        somaPrecos / totalJogos;

// Variável para armazenar a média dos jogos vendidos
    float mediaJogosVendidos = 0;

// Evita divisão por zero
    if(quantidadeJogosVendidos > 0){
        mediaJogosVendidos =
            somaPrecosVendidos /
            quantidadeJogosVendidos;
    }

// Exibição do relatório
    printf("\n=====================================\n");
    printf("          RELATORIO GERAL\n");
    printf("=====================================\n");

    printf("Jogo mais vendido: %s\n",
           jogo[indiceMaisVendido].nome);

    printf("Quantidade total de downloads: %d\n",
           totalDownloads);

    printf("Faturamento bruto: R$ %.2f\n",
           faturamentoBruto);

    printf("Impostos (20%%): R$ %.2f\n",
           imposto);

    printf("Faturamento liquido: R$ %.2f\n",
           faturamentoLiquido);

    printf("Media dos valores dos jogos: R$ %.2f\n",
           mediaJogos);

    printf("Media dos valores dos jogos vendidos: R$ %.2f\n",
           mediaJogosVendidos);

    printf("Jogo mais caro: %s (R$ %.2f)\n",
           jogo[indiceMaisCaro].nome,
           jogo[indiceMaisCaro].preco);

    printf("Jogo mais barato: %s (R$ %.2f)\n",
           jogo[indiceMaisBarato].nome,
           jogo[indiceMaisBarato].preco);

    printf("=====================================\n");
}