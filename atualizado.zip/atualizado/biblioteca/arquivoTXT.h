//biblioteca para manipular arquivos de texto
#ifndef ARQUIVO_TXT_H
#define ARQUIVO_TXT_H

void lerArquivo();
void editarArquivo();
void criarArquivo();

#endif // ARQUIVO_TXT_H