//biblioteca para manipular arquivos de texto
#ifndef ARQUIVO_TXT_H
#define ARQUIVO_TXT_H

void lerArquivo();
void editarArquivo(int n);
void criarArquivo(int n);
void atualizarVendas(char nomeJogo[30], int quantidade);
void buscarJogo(char nomeJogo[30]);

#endif // ARQUIVO_TXT_H