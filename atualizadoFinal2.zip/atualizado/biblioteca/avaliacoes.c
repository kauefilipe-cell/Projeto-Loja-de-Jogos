#include <stdio.h>
#include <string.h>
#include "avaliacoes.h"

#define MAX_JOGOS 255
#define MAX_AVALIACOES 10

// Struct dos jogos
struct Jogos
{
    char nome[30];
    char genero[20];
    float preco;
    int classificacao;
    int vendas;
    float faturamento;
};

// Matriz de avaliações
int avaliacoes[MAX_JOGOS][MAX_AVALIACOES] = {0};

// Quantidade de avaliações de cada jogo
int qtdAvaliacoes[MAX_JOGOS] = {0};

// Vetor para armazenar os nomes dos jogos
char nomesJogos[MAX_JOGOS][30];

// Quantidade de jogos carregados
int totalJogos = 0;

// Função carregar os jogos do arquivo
void carregarJogos()
{

    FILE *arquivo;

    arquivo = fopen("jogos.txt", "r");

    if (arquivo == NULL)
    {
        printf("Erro ao abrir jogos.txt\n");
        return;
    }

    totalJogos = 0;

    while (totalJogos < MAX_JOGOS &&
           fscanf(arquivo,
                  "{\n   %[^;];%[^;];%*f;%*d;%*d;%*f\n}\n",
                  nomesJogos[totalJogos],
                  (char[20]){0}) == 2)
    {
        totalJogos++;
    }

    fclose(arquivo);
}

// Registrar avaliação
void registrarAvaliacao()
{

    carregarJogos();

    printf("\n=====================================\n");
    printf("               JOGOS\n");
    printf("=====================================\n");

    if (totalJogos == 0)
    {
        printf("Nenhum jogo cadastrado!\n");
        return;
    }

    int jogo;
    int nota;

    for (int i = 0; i < totalJogos; i++)
    {
        printf("%d - %s\n", i, nomesJogos[i]);
    }

    printf("Escolha um jogo: ");
    scanf("%d", &jogo);

    if (jogo < 0 || jogo >= totalJogos)
    {
        printf("Jogo invalido!\n");
        return;
    }

    printf("Digite uma nota (1 a 5): ");
    scanf("%d", &nota);

    if (nota < 1 || nota > 5)
    {
        printf("Nota invalida!\n");
        return;
    }

    if (qtdAvaliacoes[jogo] >= MAX_AVALIACOES)
    {
        printf("Limite de avaliações atingido!\n");
        return;
    }

    avaliacoes[jogo][qtdAvaliacoes[jogo]] = nota;

    qtdAvaliacoes[jogo]++;

    printf("Avaliação registrada com sucesso!\n");

    printf("=====================================\n");
}
// Quantidade total de avaliações
void exibirQuantidadeAvaliacoes()
{
    int total = 0;

    for (int i = 0; i < totalJogos; i++)
    {
        total += qtdAvaliacoes[i];
    }

    printf("\n=====================================\n");
    printf("               MEDIAS\n");
    printf("=====================================\n");

    printf("\nQuantidade total de avaliações: %d\n",
           total);
}

// media das avaliações
void exibirMediaAvaliacoes()
{

    for (int i = 0; i < totalJogos; i++)
    {

        if (qtdAvaliacoes[i] > 0)
        {

            float soma = 0;

            for (int j = 0; j < qtdAvaliacoes[i]; j++)
            {
                soma += avaliacoes[i][j];
            }

            printf("%s -> %.2f\n",
                   nomesJogos[i],
                   soma / qtdAvaliacoes[i]);
        }
    }
}

// Jogo mais bem avaliado
void exibirJogoMaisBemAvaliado()
{

    int melhorJogo = -1;
    float melhorMedia = 0;

    for (int i = 0; i < totalJogos; i++)
    {

        if (qtdAvaliacoes[i] > 0)
        {

            float soma = 0;

            for (int j = 0; j < qtdAvaliacoes[i]; j++)
            {
                soma += avaliacoes[i][j];
            }

            float media = soma / qtdAvaliacoes[i];

            if (media > melhorMedia)
            {
                melhorMedia = media;
                melhorJogo = i;
            }
        }
    }

    if (melhorJogo != -1)
    {

        printf("Jogo mais bem avaliado: %s\n",
               nomesJogos[melhorJogo]);

        printf("Maior Media: %.2f\n",
               melhorMedia);
    }
    else
    {

        printf("Nenhuma avaliação registrada.\n");
    }

    printf("=====================================\n");
}