//menu da loja de jogos, onde o cliente pode escolher entre pesquisar os jogos ou cadastrar novos jogos no sistema, comprar jogos ou sair do sistema.
#include <stdio.h>
#include <stdlib.h>
#include "biblioteca/arquivoTXT.h"
#include "biblioteca/avaliacoes.h"
#include "biblioteca/relatorio.h"

int main(){
    int menu;
    int n;
    //Pesquisa de jogos; cadastro de jogos; compra de jogos;

    do{
        printf("================Menu de Jogos===================\n");
        printf("(1) - Pesquisar jogos\n");
        printf("(2) - Cadastrar novos jogos no sistema\n");
        printf("(3) - Registrar venda de jogos\n");
        printf("(4) - Gerar relatorio\n");
        printf("(5) - Registrar avaliação\n");
        printf("(6) - Relatório de avaliações\n");
        printf("(0) - Sair!!\n");
        printf("Digite o que vc deseja utilizar: ");
        scanf("%d", &menu);

        switch (menu){
        case 1:
            
            printf("\nPesquisar jogos funcionou\n\n");
            break;

        case 2: 

        int n;

            printf("Digite o número de jogos a cadastrar: ");
            scanf("%d", &n);

            //verificar se o arquivo já existe, caso o arquivo já exista, não será criado um novo arquivo, apenas será aberto o arquivo existente
            if (n > 0 && fopen("jogos.txt", "r") == NULL) {
                //criarArquivo();
                criarArquivo(n);
            }

            if(n > 0){
                //chamar a função para editar o arquivo e adicionar um novo jogo ao final do arquivo
                editarArquivo(n);
            }
        
            break;
        
        case 3:
            
            printf("\nAtualizar vendas funcionou\n\n");
            break;

        case 4:

    gerarRelatorio();
    break;

        case 5:

    registrarAvaliacao();
    break;

        case 6:

    exibirQuantidadeAvaliacoes();
    exibirMediaAvaliacoes();
    exibirJogoMaisBemAvaliado();
    break;

    default:
    printf("Opcao invalida!\n");
    break;
    }

    }while(menu != 0);

    printf("\nVc saiu do sistema\n\n");
}
