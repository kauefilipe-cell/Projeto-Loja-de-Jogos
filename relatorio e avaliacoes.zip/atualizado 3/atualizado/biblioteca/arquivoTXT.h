//biblioteca para manipular arquivos de texto
#ifndef ARQUIVO_TXT_H
#define ARQUIVO_TXT_H

void lerArquivo();
void editarArquivo(int n);
void criarArquivo(int n);

#endif // ARQUIVO_TXT_H